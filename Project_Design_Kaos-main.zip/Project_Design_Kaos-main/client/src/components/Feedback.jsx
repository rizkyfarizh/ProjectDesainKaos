import React from 'react';

// Assuming you have an image called 'download.jpg' in the same directory
import download from './download.jpg';

const Feedback = () => {
    return (
        <a href="http://127.0.0.1:5000/#" className="btn" target="_blank" rel="noopener noreferrer">
        </a>
    );
}

export default Feedback;